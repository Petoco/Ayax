module.exports = {
  Admins: ["528597546252369920"], //Admins of the bot
  ExpressServer: true, //If you wanted to make the website run or not
  DefaultPrefix: process.env.Prefix || ".", //Default prefix, Server Admins can change the prefix
  Port: 3002, //Which port website gonna be hosted
  SupportServer: "https://discord.gg/8CNau43SDC", //Support Server Link
  Token: process.env.Token || "NzgyMjQyOTM5NTI1OTIyODI2.X8JWgg.uYwGxn8anbAyfYMXOVghdDpIcfg", //Discord Bot Token
  ClientID: process.env.Discord_ClientID || "782242939525922826", //Discord Client ID
  ClientSecret: process.env.Discord_ClientSecret || "H7bDLc_DkIzQupuC_-ZWM9qhoQkWJvdc", //Discord Client Secret
  Scopes: ["identify", "guilds", "applications.commands"], //Discord OAuth2 Scopes
  ServerDeafen: true, //If you want bot to stay deafened
  DefaultVolume: 100, //Sets the default volume of the bot, You can change this number anywhere from 1 to 100
  CallbackURL: "/api/callback", //Discord API Callback url. Do not touch it if you don't know what you are doing. All you need to change for website to work is on line 20.
  "24/7": true, //If you want the bot to be stay in the vc 24/7
  CookieSecret: "Pikachu is cute", //A Secret like a password
  IconURL:
    "https://media.discordapp.net/attachments/734844209839996960/1000080019634278581/Nuevo_Ayax.jpg?width=702&height=702", //URL of all embed author icons | Dont edit unless you dont need that Music CD Spining
  EmbedColor: "#d300ff", //Color of most embeds | Dont edit unless you want a specific color instead of a random one each time
  Permissions: 2205281600, //Bot Inviting Permissions
  Website: process.env.Website || "https://ayax-xyz.glitch.me", //Website where it is hosted at includes http or https || Use "0.0.0.0" if you using Heroku || Do not include /api/callback. Just the website url. I.e. "https://foo.bar"
  //If you get invalid oauth, make sure on the discord developer page you set the oauth url to something like: https://example.com/api/callback.
  
  Presence: {
    status: "online", // You can show online, idle, and dnd
    name: ".play | ayax-xyz.glitch.me", // The message shown
    type: "LISTENING", // PLAYING, WATCHING, LISTENING, STREAMING
  },

   // Lavalink server; public lavalink -> https://lavalink-list.darrennathanael.com/; create one yourself -> https://darrennathanael.com/post/how-to-lavalink/
  // The default one should work fine, altho if you have issue with it, you can create your own or use another public lavalink.
  Lavalink: {
    id: "Ayax", //- Used for indentifier. You can set this to whatever you want.
    host: "localhost", //- The host name or IP of the lavalink server.
    port: 3000, // The port that lavalink is listening to. This must be a number!
    pass: "petoco", //- The password of the lavalink server.
    secure: false, // Set this to true if the lavalink uses SSL. if not set it to false.
    retryAmount: 9999999, //- The amount of times to retry connecting to the node if connection got dropped.
    retryDelay: 40, //- Delay between reconnect attempts if connection is lost.
}, 

  //Please go to https://developer.spotify.com/dashboard/
  Spotify: {
    ClientID: process.env.Spotify_ClientID || "c98553f9cc224268826ea9143fca30fc", //Spotify Client ID
    ClientSecret: process.env.Spotify_ClientSecret || "174cc5921fa14953a85f4e3a867948f3", //Spotify Client Secret
  },
};
